1. HomePage

    HomePage has the links to go to:
    1. Unit Timetable
    2.Unit Enrolment
    3. Registration
    4. Login
    
2. UnitDetails Page

    -It displays all the units. 
    -User should click on the green double down arrow on the right side to view the details about the unit.
    -Clicking on the Enrol button after expanding takes the user to User Enrolment page
    

3. UnitEnrolment Page

    -There is a logout button on top as it is assumed that students can only access this page once they login
    -Dropdown menus on top display various options to select available units(Note: Search will not filter at this instance
    -Clicking on more Details takes the user back to unitDetails page to get more information about the unit
    -Clicking on Logout takes back to homepage
    
4. Timetable Page

    -Link available on the homepage
    -Has a logout menu on top as it is assumed that user can only enter this page after logging in successfully
    -Left and Right green arrows on top changes weekly view along with the dates
    -It has a link for Tutorial Allocation page and Enrolment

    
5. TUTORIAL ALLOCATION PAGE
    -Accessed from Timetable page
    -The left-side box displays all the units the person is emrolled in.
    -Clicking on the down arrow icon on the side of each unit will show LEC and TUT. Only the first arrow will work for this assignment.
    -When the green arrow icon is clicked the span text on the right side of the page will display the unit that is selected.
    -Please click on TUT for the first unit.
    -It will display all the different tutorials available for selection on the right side of the page.
    
    -To select a tutorial, please click on any of the classes available. After clicking, it will become allocated and another time cannot be selected. After unselecting the clicked button, other choices become available. This is to prevent from user selecting multiple classes. 
    -It has a link for timetable and logout on top.
    
    -On logout, user is returned to homepage.
    
2. AcademicStaffMasterPage.html

    This displays the staff members.
        -User need to click on the checkbox to select the staff member.
        -I recommend to use remove button first to remove the selected staff memeber from the list.
        -After the checkbox is checked, remove will remove the staff from the list
        -When Allocate button is clicked, a pop up dialog appears which allows to select semester, unit and campus so that the unit coordinator can be allocated. Clicking on Cancel closes this pop up dialog box
        - Create a new Staff will pop up a form to enter new values. On clicking the 'Create a New Staff' the values will be transferred to the main table. (Note: Two checkboxes appear for each time the button is clicked) 
    
3. UnitDetailsMasterPage
        -It displays detailed information about all the units
        -It has a logout button which will take back to homepage